package com.zks.myspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyspringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
